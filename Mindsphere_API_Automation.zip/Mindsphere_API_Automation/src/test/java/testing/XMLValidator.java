package testing;

import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.input.sax.XMLReaderJDOMFactory;
import org.jdom2.input.sax.XMLReaderXSDFactory;

import java.io.IOException;
import java.net.URL;

public class XMLValidator {

	public static void main(String args[]) throws JDOMException, IOException {

		URL xml = XMLValidator.class.getResource("records.xml");
		URL xsd = XMLValidator.class.getResource("records.xsd");

		XMLReaderJDOMFactory factory = new XMLReaderXSDFactory(xsd);
		SAXBuilder builder = new SAXBuilder(factory);
		Document document = builder.build(xml);

		System.out.println("root: " + document.getRootElement().getName() + " Validated Successfully ");

	}
}