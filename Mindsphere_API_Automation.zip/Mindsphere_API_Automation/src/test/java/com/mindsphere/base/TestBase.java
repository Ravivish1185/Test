package com.mindsphere.base;

import io.restassured.RestAssured;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeSuite;

import com.mindsphere.util.Xls_Reader;

//import test.Logging;

public class TestBase {

	public static Logger APP_LOGS = null;
	public static Properties CONFIG = null;
	public static Properties OR = null;

	public static Xls_Reader suiteXls = null;
	public static Xls_Reader suiteAxls = null;
	public static Xls_Reader suiteBxls = null;
	public static Xls_Reader suiteCxls = null;

	public static boolean isInitialized = false;

	@BeforeSuite
	public void proxy() {

		RestAssured.proxy("10.87.140.12", 84);
	}

	// ***************************************************************************************************

	public void initialize() throws IOException {
		// public static void main(String[] args) {

		// String log4jConfigFile = "D://DataDrivenWith
		// Junit//Core_Framework//src//test//log4j.properties";

		if (!isInitialized) {

			// String log4jConfigFile = ((System.getProperty("user.dir")
			// + "/src//com//mindsphere//config//log4j.properties"));

			String log4jConfigFile = "C:\\Users\\A622976\\workspace\\Mindsphere_API_Automation\\Mindsphere_API_Automation\\src\\test\\java\\com\\mindsphere\\config\\log4j.properties";
			PropertyConfigurator.configure(log4jConfigFile);

			// logs
			// config
			// data from xls
			Logger APP_LOGS = Logger.getLogger("rootlogger");

			// *************************************************************************************************//
			APP_LOGS.info("Loading nitish Files");

			APP_LOGS.debug("Loading Property Files");
			// Properties CONFIG = new Properties();
			CONFIG = new Properties();

			// FileInputStream fip = new FileInputStream(
			// System.getProperty("user.dir") +
			// "//src//com//mindsphere//config//CONFIG.properties");

			FileInputStream fip = new FileInputStream(
					"C:/Users/A622976/workspace/Mindsphere_API_Automation/Mindsphere_API_Automation/src/test/java/com/mindsphere/config/CONFIG.properties");

			CONFIG.load(fip);
			System.out.println(CONFIG.getProperty("deviceType"));

			// Properties OR = new Properties();
			OR = new Properties();

			FileInputStream fip2 = new FileInputStream(
					"C:/Users/A622976/workspace/Mindsphere_API_Automation/Mindsphere_API_Automation/src/test/java/com/mindsphere/config/CONFIG.properties");

			// FileInputStream fip2 = new FileInputStream(
			// System.getProperty("user.dir") +
			// "//src//com//mindsphere//config//OR.properties");
			OR.load(fip2);
			System.out.println(OR.getProperty("linkText"));
			APP_LOGS.debug("Loaded Property Files Successfully");
			// ***************************************************************************************************//
			// xls file
			// suiteXls= new Xls_Reader((System.getProperty("user.dir") +
			// "/src/com/mindsphere/xls/Suite.xlsx"));
			// suiteAxls= new Xls_Reader((System.getProperty("user.dir") +
			// "/src/com/mindsphere/xls/A Suite.xlsx"));
			// suiteBxls= new Xls_Reader((System.getProperty("user.dir") +
			// "/src/com/mindsphere/xls/B Suite.xlsx"));
			// suiteCxls= new Xls_Reader((System.getProperty("user.dir") +
			// "/src/com/mindsphere/xls/C Suite.xlsx"));
			// xls file
			suiteXls = new Xls_Reader(
					"C://Users//A622976//workspace//Mindsphere_API_Automation/Mindsphere_API_Automation//src//test//java//com//mindsphere//xls//Suite.xlsx");
			suiteAxls = new Xls_Reader(
					"C://Users//A622976//workspace//Mindsphere_API_Automation/Mindsphere_API_Automation//src//test//java//com//mindsphere//xls//A Suite.xlsx");
			APP_LOGS.debug("Loaded XLS files successfully");
			// isInitialized =true;
		}

	}
}
