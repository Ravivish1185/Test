package com.mindsphere.base;

import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class RestAssuredConfiguration {

	@BeforeSuite(alwaysRun = true)
	public void configure() {

		RestAssured.baseURI = "http://api.fixer.io";
		
	//	RestAssured.baseURI = "http://samples.openweathermap.org";
		// RestAssured.port = "";
		
		//RestAssured.basePath = "/latest";
		//RestAssured.basePath = "/data/2.5";
//http://samples.openweathermap.org/data/2.5/weather?zip=99524,us&appid=b1b15e88fa797225412429c1c50c122a1
	}

	public RequestSpecification getRequestSpecification(){
		return RestAssured.given().contentType(ContentType.JSON);
		
		
	}
	
}
