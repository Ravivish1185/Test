package com.mindsphere.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TestUtil {

	/**
	 * 
	 * @param xls       main suite ka object
	 * @param SuiteName childSuite excel ka name
	 * @return
	 */

	public static boolean isSuiteRunnable(Xls_Reader xls, String SuiteName) {
		boolean isExecutable = false;
		// row srart with 2

		/**
		 * Test Suite : name of main suite sheet
		 */
		for (int i = 2; i <= xls.getRowCount("Test Suite"); i++) { // Test Suit -> sheet Name
			// String suite = xls.getCellData("Test Suite", "TSID", i);
			// String runmode = xls.getCellData("Test Suite", "Runmode", i);
			if (xls.getCellData("Test Suite", "TSID", i).equalsIgnoreCase(SuiteName)) { // String sheetName,String
																						// colName,int rowNum
				if (xls.getCellData("Test Suite", "Runmode", i).equalsIgnoreCase("Y")) {
					// System.out.println("passed");
					isExecutable = true;
				} else {
					isExecutable = false;
				}
			}
		}
		// release memory
		xls = null;
		return isExecutable;
	}

	// returns true if runmode is Y
	public static boolean isTestCaseRunnable(Xls_Reader xls, String testCaseName) {
		boolean isTestExecutable = false;
		// System.out.println(isTestExecutable);
		for (int i = 2; i <= xls.getRowCount("Test Cases"); i++) { // Test Cases is sheet name
			// String tcid = xls.getCellData("Test Cases", "TCID", i);
			// String runmode = xls.getCellData("Test Cases", "Runmode", i);
			// System.out.println(tcid +"--"+ runmode);
			if (xls.getCellData("Test Cases", "TCID", i).equalsIgnoreCase(testCaseName)) {
				if (xls.getCellData("Test Cases", "Runmode", i).equalsIgnoreCase("Y")) {
					isTestExecutable = true;
				} else {
					isTestExecutable = false;
				}

			}
		}

		return isTestExecutable;

	}

	public static Object[][] getData(Xls_Reader xls, String testCaseName) {

		// if sheet is not present
		if (!xls.isSheetExist(testCaseName)) {
			xls = null;
			return new Object[1][0];
		}
		int rows = xls.getRowCount(testCaseName);
		int cols = xls.getColumnCount(testCaseName);
		// System.out.println("Rows are -- " + rows);
		// System.out.println("Cols are -- " + cols);

		Object[][] data = new Object[rows - 1][cols - 3];
		for (int rowNum = 2; rowNum <= rows; rowNum++) {
			for (int colNum = 0; colNum < cols - 3; colNum++) {
				// System.out.print(xls.getCellData(testCaseName, colNum,
				// rowNum) + "---");
				data[rowNum - 2][colNum] = xls.getCellData(testCaseName, colNum, rowNum);

			}
			// System.out.println();
		}

		return data;
	}

	// update test data
	public static void reportDataSetResult(Xls_Reader xls, String testCaseName, int rowNum, String result) {

		xls.setCellData(testCaseName, "Results", rowNum, result);

	}

	public static void reportActualResponseData(Xls_Reader xls, String testCaseName, int rowNum, String result) {
		xls.setCellData(testCaseName, "Response_Actual", rowNum, result);

	}

//checks runmode for dataset
	public static String[] getDataSetRunmodes(Xls_Reader xlsFile, String sheetName) {
		String[] runModes = null;
		if (!xlsFile.isSheetExist(sheetName)) {
			xlsFile = null;
			sheetName = null;
			runModes = new String[1];
			runModes[0] = "Y";
			xlsFile = null;
			sheetName = null;
			return runModes;

		}
		runModes = new String[xlsFile.getRowCount(sheetName) - 1];
		for (int i = 2; i <= runModes.length + 1; i++) {
			runModes[i - 2] = xlsFile.getCellData(sheetName, "Runmode", i);
		}
		xlsFile = null;
		sheetName = null;
		return runModes;

	}

//RETURN ROW NUMBER  
	// Used during reporting time

	// public static int getRowNum(Xls_Reader xls, String sheetName, String id){

	public static int getRowNum(Xls_Reader xls, String id) {

		for (int i = 2; i <= xls.getRowCount("Test Cases"); i++) {
			String tcid = xls.getCellData("Test Cases", "TCID", i);

			if (tcid.equals(id)) {
				xls = null;
				return i;
			}
		}
		return -1;
	}

	public static boolean compareJSON(String actual, String expected) {
		boolean status = false;
		try {
			JSONArray actualJson = new JSONArray(actual);
			JSONArray repuiredJson = new JSONArray(expected);
			JSONObject obj1 = null, obj2 = null;
			for (int i = 0; i < repuiredJson.length(); i++) {
				obj1 = actualJson.getJSONObject(i);
				obj2 = repuiredJson.getJSONObject(i);
				Iterator<?> keys = obj2.keys();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					if (obj2.getString(key).equalsIgnoreCase(obj1.getString(key)))
						status = true;
					else
						status = false;
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;

	}

	public static boolean compareJSONArray(String actual, String expected) {
		boolean status = false;
		try {
			JSONArray actualJson = new JSONArray(actual);
			JSONArray requiredJson = new JSONArray(expected);
			JSONObject obj1 = null, obj2 = null;
			for (int i = 0; i < requiredJson.length(); i++) {
				obj1 = actualJson.getJSONObject(i);
				obj2 = requiredJson.getJSONObject(i);
				Iterator<?> keys = obj2.keys();
				while (keys.hasNext()) {
					String key = (String) keys.next();
					if (obj2.get(key) instanceof JSONArray) {
						if (!compareJSONArray(obj2.getString(key), obj1.getString(key))) {
							return false;
						}
						status = true;
					} else if (obj2.get(key) instanceof JSONObject) {
						if (!compareJSON(obj2.getString(key), obj1.getString(key))) {
							return false;
						}
						status = true;
					} else {
						if (obj2.getString(key).equalsIgnoreCase(obj1.getString(key))) {

							status = true;
						} else {
							return false;
						}

					}
				}
			}

		} catch (JSONException e) {
			if (actual.trim().equalsIgnoreCase(expected.trim())) {
				return true;
			}
			if (compareJSON(actual, expected))
				return true;
			System.out.println("*******************Reach to Exception*****************");
			// e.printStackTrace();
			return false;
		}
		return status;
	}
}
