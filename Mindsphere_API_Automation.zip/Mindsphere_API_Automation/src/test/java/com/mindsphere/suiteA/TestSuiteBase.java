package com.mindsphere.suiteA;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.SkipException;
import org.testng.annotations.BeforeSuite;

import com.mindsphere.base.TestBase;
import com.mindsphere.util.TestUtil;

public class TestSuiteBase extends TestBase {

	@BeforeSuite
	public void checkSuiteSkip() throws IOException{
		APP_LOGS = Logger.getLogger("rootlogger");
		initialize();		//TestBase.java
		//System.out.println(TestUtil.isSuiteRunnable(suiteXls, "A Suite"));
		System.out.println("******************************************************");
		//applogger.debug("checking runmode of suite A");
		
		// means mainSuit me se only A Suit ka runMode chrck kar rahe hai (MainSuitExcelReference,SubsuitName)
		if(!TestUtil.isSuiteRunnable(suiteXls,"A Suite")){    
			//Logger APP_LOGS = Logger.getLogger("rootlogger");

		//	System.out.println(TestUtil.isSuiteRunnable(suiteXls, "A Suite"));
			APP_LOGS.debug("skipping  runmode of suite A");
		//	System.out.println("suite xls"+suiteXls);
			throw new SkipException("Runmode of Suite A is set to No. So skipping all tests");
			
		}
		
		
	}

}
