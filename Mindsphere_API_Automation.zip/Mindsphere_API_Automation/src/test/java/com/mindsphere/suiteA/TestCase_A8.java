package com.mindsphere.suiteA;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
//import org.apache.poi.ddf.EscherColorRef.SysIndexSource;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindsphere.base.RestAssuredConfiguration;
import com.mindsphere.util.JsonValidation;
import com.mindsphere.util.TestUtil;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import com.mindsphere.util.TestUtil;

public class TestCase_A8 extends TestSuiteBase {
	String runModes[] = null;
	static int count = -1;
	static boolean pass = false;
	static boolean fail = false;
	static boolean skip = false;
	static boolean isTestPass = false;
	String expected = null;

	String actual = null;

	// RunMode of TestCase in a suite
	@BeforeTest
	public void checkTestSkip() {
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {

			System.out.println("TestCaseA3 Will be skipped" + this.getClass().getSimpleName());
			APP_LOGS.debug("Skipping Test Case A1 as runmode set to no"); // logs
			throw new SkipException("Skipping Test Case A1 as runmode set to no"); // reports
		}
		// load the runmode off the test

		runModes = TestUtil.getDataSetRunmodes(suiteAxls, this.getClass().getSimpleName());
	}

	@Test(dataProvider = "getTestData")
		
	public void testCaseA5(String API_Endpoint, String RequestType, String Header_Info, String Request_Post,
			String Response_Expected, String Response_Actual) {
		// test the runmode of current dataset
		count++;
		if (!runModes[count].equalsIgnoreCase("Y")) {
			skip = true;
			throw new SkipException("Runmode of test set data set to no" + count);

		}

		try {
				Response ActualResponse = when().
		            get(CONFIG.getProperty("api_base") + API_Endpoint).then().
	                contentType(ContentType.JSON).  // check that the content type return from the API is JSON
	            extract().response();
			//System.out.print("actualresponse "+ActualResponse.asString());
			boolean firstStringValid = JsonValidation.isJSONValid(ActualResponse.asString());
			//printing actual response
			TestUtil.reportActualResponseData(suiteAxls, this.getClass().getSimpleName(), count + 2, ActualResponse.asString());
			
			if (firstStringValid == true) {
				System.out.println("Json Is Valid");
			}
		    
			System.out.println(ActualResponse.asString().equals(Response_Expected));
			if (ActualResponse.asString().equals(Response_Expected)) {
				System.out.println("Response is matching with expected");
			} 
			else  {
				System.out.println("Response is not matching with expected");
				Assert.fail("Response not matching with expected");

			} 
		    System.out.print("actualresponse "+ActualResponse.asString());
		} catch (Throwable t) {
			fail = true;
			Assert.fail("Response not matching with expected");
			return;
		}
	}

	@AfterMethod
	public void reportDataSetResult() {

		if (skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "SKIP");

		else if (fail) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "FAIL");
			isTestPass = false;
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "PASS");
			isTestPass = true;
		}

		skip = false;
		// pass=false;
		fail = false;

	}

	@AfterTest
	public void reportTestResult() {
		if (isTestPass) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Passed");
		} 
		else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Failed");
		}

	}

	@DataProvider
	public Object[][] getTestData() {
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());
	}
}
