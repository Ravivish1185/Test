package com.mindsphere.suiteA;

//import org.apache.poi.ddf.EscherColorRef.SysIndexSource;
import static io.restassured.RestAssured.when;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.mindsphere.util.JsonValidation;
import com.mindsphere.util.TestUtil;

//import commonpkg.Endpoint;
//import commonpkg.Endpoint;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TestCase_A1 extends TestSuiteBase {
	String runModes[] = null;
	static int count = -1;
	static boolean pass = false;
	static boolean fail = false;
	static boolean skip = false;
	static boolean isTestPass = false;
	String expected = null;
	String actual = null;

	// RunMode of TestCase in a suite
	@BeforeTest
	public void checkTestSkip() {
		System.out.println("In***checkTestSkip\n");
		// if(!TestUtil.isTestCaseRunnable(suiteAxls, "TestCase_A1")){
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {

			// System.out.println("Hello" + this.getClass().getSimpleName());
			APP_LOGS.debug("Skipping Test Case A1 as runmode set to no"); // logs
			throw new SkipException("Skipping Test Case A1 as runmode set to no"); // reports
		}
		// load the runmode off the test

		runModes = TestUtil.getDataSetRunmodes(suiteAxls, this.getClass().getSimpleName());
	}

	@Test(dataProvider = "getTestData")
	public void testCaseA1(String API_Endpoint, String RequestType, String Header_Info, String Request_Post,
			String Response_Expected, String Response_Actual) {
		// System.out.println("In***testCaseA1\n");
		// test the runmode of current dataset
		count++;
		if (!runModes[count].equalsIgnoreCase("Y")) {
			skip = true;
			throw new SkipException("Runmode of test set data set to no" + count);

		}
		try {

			// CONFIG.getProperty("api_base") + API_Endpoint
			Response ActualResponse = when().get(CONFIG.getProperty("api_base") + API_Endpoint).then()
					.contentType(ContentType.JSON). // check that the content type return from the API is JSON
					extract().response();
			/*
			 * String ActualResponseData = ActualResponse.asString();
			 * System.out.print("actualresponse "+ActualResponseData);
			 */
			// printing actual response
			/*
			 * String[] ar = new String[10]; try { JSONArray baseArray =new
			 * JSONArray(ActualResponse.body().asString()); for(int i =0; i <
			 * baseArray.length(); i++) { org.json.JSONObject
			 * item=baseArray.getJSONObject(i); ar[i]=item.getString("siteLocation");
			 * System.out.println(ar[i]+"\n"); } } catch(Exception e) {
			 * System.out.println(e); } //contains condition String
			 * actualdata=ar[0]+":".concat(ar[1])+":".concat(ar[2])+":".concat(ar[3])+":".
			 * concat(ar[4]);
			 */
			// TestUtil.reportActualResponseData(suiteAxls, this.getClass().getSimpleName(),
			// count+2,Response_Expected);
			boolean firstStringValid = JsonValidation.isJSONValid(ActualResponse.asString());
			// System.out.println(firstStringValid+"hello");
			if (firstStringValid == true) {
				System.out.println("Json Is Valid");
			}
			// String test = JSONObject.escape(response.asString());
			// System.out.println(ActualResponse.asString().equals(Response_Expected));
			boolean results = TestUtil.compareJSONArray(ActualResponse.asString(), Response_Expected);
			if (results = true) {
				// System.out.println("Response is matching with expected");
				TestUtil.reportActualResponseData(suiteAxls, this.getClass().getSimpleName(), count + 2,
						Response_Expected);
			} else {
				// System.out.println("Response is not matching with expected");
				Assert.fail("Response not matching with expected");

			}
		} catch (Throwable t) {
			fail = true;
			Assert.fail("Response not matching with expected");
			return;
		}
	}

	@AfterMethod
	public void reportDataSetResult() {
		// System.out.println("In***reportDataSetResult\n");

		if (skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "SKIP");

		else if (fail) {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "FAIL");
			isTestPass = false;
		} else {
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "PASS");
			isTestPass = true;
		}

		skip = false;
		// pass=false;
		fail = false;

	}

	@AfterTest

	public void reportTestResult() {
		// System.out.println("In***reportTestResult\n");
		if (isTestPass) {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Passed");
		} else {
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "Failed");
		}

	}

	@DataProvider
	public Object[][] getTestData() {
		System.out.println("In***getTestData\n");
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());
	}
}
